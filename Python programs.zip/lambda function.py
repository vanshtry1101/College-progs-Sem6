square=lambda n1:n1**2
n1=int(input("enter number to print square:"))
print(square(n1))

dinner={'starter':None, 'maincourse':None }

for keys in dinner.keys():
    dinner[keys]=input(f"enter {keys} value: ")

print(dinner)

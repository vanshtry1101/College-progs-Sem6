list1=[]
n=int(input("enter number of elements you want:"))
for i in range(n+1):
    ele=input("enter first string:")
    list.append(ele)
print(list1)

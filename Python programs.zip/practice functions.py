def sub(n1,n2):
    if(type(n1)==int and type(n2)==int):
        sub=n1-n2
        print("Subtraction:",sub)
    else:
        print("ener integer:")
         
    
num1=int(input("Enter 1st integer:"))
num2=int(input("Enter 2nd integer:"))
sub(num1,num2)

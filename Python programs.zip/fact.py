number=int(input("Enter Number"))
n=1
for number in range(1,number+1):
    n=n*number
print(n)

import sys
str1=input("")

#menu driven
print("")

while(True):
    choice=int(input ("choice"))
    if(choice==1)
    pass
    if(choice==3)
    break
    sys.exit()

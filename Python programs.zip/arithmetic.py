def add(n1,n2):
    return n1+n2
def sub(n1,n2):
    return n1-n2
def mul(n1,n2):
    return n1*n2
def div(n1,n2):
    return n1/n2

if(__name__=="__main__"):
    print("This runs as program")
else:
    print("This runs as module")

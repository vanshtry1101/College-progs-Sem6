print("----------------Welcome to pizza house----------------------")

# functions
def menu():
    menu={"Tandoori Pizza":300,}

while(True):
    print("1.Choose pizza")


    choice=int(input("Enter your choice:"))
    if(choice==1):
        pass
    if(choice==2):
        pass
    if(choice==3):
        break
    else:
        print("Invalid input")

print("------------------Shukriyaaa----------------------------------")
